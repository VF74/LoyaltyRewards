package com.cxl.rewards.util;

/**
 * 
 * @author rmoon
 *
 */
public class SpeechConstants 
{
		private SpeechConstants() {}
		
		public static final String NEXT = "What can I help you with next";
		public static final String LASTEST_REDEMPTIONS = "Would you like to see the status of your latest redemptions... just say status";

}
